export const coinflip = () => Math.random() > 0.5;
